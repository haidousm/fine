class Layer_Input:
    def forward(self, inputs, training):
        self.output = inputs

